package xyz.chengzi.aeroplanechess.listener;

public interface Listener {
}
