package xyz.chengzi.aeroplanechess.model;

public class Square {
    private final ChessBoardLocation location;
    private ChessPiece piece;

    public Square(ChessBoardLocation location) {
        this.location = location;
    }

    public ChessBoardLocation getLocation() {
        return location;
    }

    public ChessPiece getPiece() {
        return piece;
    }

    public void setPiece(ChessPiece piece) {
        this.piece = piece;
    }
//    public void setPiece(ChessPiece2 piece) {
//        this.piece = piece;
//    }
//    public void setPiece(ChessPiece3 piece) {
//        this.piece = piece;
//    }
//    public void setPiece(ChessPiece4 piece) {
//        this.piece = piece;
//    }


}
