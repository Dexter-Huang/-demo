package xyz.chengzi.aeroplanechess.controller;

import xyz.chengzi.aeroplanechess.listener.GameStateListener;
import xyz.chengzi.aeroplanechess.listener.InputListener;
import xyz.chengzi.aeroplanechess.listener.Listenable;
import xyz.chengzi.aeroplanechess.model.*;
import xyz.chengzi.aeroplanechess.util.RandomUtil;
import xyz.chengzi.aeroplanechess.view.*;

import java.util.ArrayList;
import java.util.List;

public class GameController implements InputListener, Listenable<GameStateListener> {


    private final List<GameStateListener> listenerList = new ArrayList<>();
    private final ChessBoardComponent view;
    private static ChessBoard model = null;

    private static Integer rolledNumber;
    private static Integer rolleddNumber;
    private static int step;
    private static int currentPlayer;
    private static boolean[] state = {false, false, false, false};
    private static boolean[] allTakeOff = {false, false, false, false};
    private static int[] grade = {0,0,0,0};

    private static int countRoll = 0;

    public GameController(ChessBoardComponent chessBoardComponent, ChessBoard chessBoard) {
        this.view = chessBoardComponent;
        model = chessBoard;

        view.registerListener(this);
        model.registerListener(view);
    }

    public ChessBoardComponent getView() {
        return view;
    }

    public ChessBoard getModel() {
        return model;
    }

    public static int getCurrentPlayer() {
        return currentPlayer;
    }

    public void initializeGame() {
        model.placeInitialPieces();
        rolledNumber = null;
        rolleddNumber = null;
        currentPlayer = 0;
        listenerList.forEach(listener -> listener.onPlayerStartRound(currentPlayer));
    }

    public int rollDice() {
        if (rolledNumber == null) {
            return rolledNumber = RandomUtil.nextInt(1, 6);

        } else {
            return -1;
        }
    }

    public int rollDdice() {
        if (rolleddNumber == null) {
            return rolleddNumber = RandomUtil.nextInt(1, 6);
        } else {
            return -1;
        }
    }


    public static int nextPlayer() {
        int count = 0;
        if (countRoll == 2) {
            if (rolleddNumber + rolledNumber >= 10) {
                for (int e = 0; e < 4; e++) {
                    for (int i = 0; i < getChessBoard().getDimension() + getChessBoard().getEndDimension(); i++) {
                        if (model.getGrid()[e][i].getPiece() != null && model.getGrid()[e][i].getPiece().getPlayer() == currentPlayer) {
                            if(model.getGrid()[e][i].getPiece().getScore()==1) count++;
                            else if (model.getGrid()[e][i].getPiece().getScore()==2) count+=2;
                            else if (model.getGrid()[e][i].getPiece().getScore()==3) count+=3;
                            else if (model.getGrid()[e][i].getPiece().getScore()==4) count+=4;
                            model.removeChessPieceAt(new ChessBoardLocation(e, i));
                            //model.setChessPieceAt(new ChessBoardLocation(currentPlayer, count), new ChessPiece(currentPlayer));
                        }
                    }
                }
                if(model.getGrid()[currentPlayer][23].getPiece()!=null){
                    if(model.getGrid()[currentPlayer][23].getPiece().getScore()==1) count++;
                    else if (model.getGrid()[currentPlayer][23].getPiece().getScore()==2) count+=2;
                    else if (model.getGrid()[currentPlayer][23].getPiece().getScore()==3) count+=3;
                    else if (model.getGrid()[currentPlayer][23].getPiece().getScore()==4) count+=4;
                    model.removeChessPieceAt(new ChessBoardLocation(currentPlayer, 23));
                }
                if(count>=1){
                    model.setChessPieceAt(new ChessBoardLocation(currentPlayer, 19), new ChessPiece(currentPlayer));
                }
                if(count>=2){
                    model.setChessPieceAt(new ChessBoardLocation(currentPlayer, 20), new ChessPiece(currentPlayer));
                }
                if(count>=3){
                    model.setChessPieceAt(new ChessBoardLocation(currentPlayer, 21), new ChessPiece(currentPlayer));
                }
                if(count>=4){
                    model.setChessPieceAt(new ChessBoardLocation(currentPlayer, 22), new ChessPiece(currentPlayer));
                }
                setState(currentPlayer,false);
                countRoll = 0;
                currentPlayer = (currentPlayer + 1) % 4;
            } else {
                currentPlayer = (currentPlayer + 1) % 4;
                countRoll = 0;
            }
        } else {
            if (rolleddNumber + rolledNumber >= 10) {
                currentPlayer = (currentPlayer) % 4;
                countRoll++;
            } else {
                currentPlayer = (currentPlayer + 1) % 4;
            }
        }
        rolledNumber = null;
        rolleddNumber = null;
        return currentPlayer;
    }

    @Override
    public void onPlayerClickSquare(ChessBoardLocation location, SquareComponent component) {
        System.out.println("clicked " + location.getColor() + "," + location.getIndex());
    }

    @Override
    public void onPlayerClickChessPiece(ChessBoardLocation location, ChessComponent component) {
        if (rolledNumber != null && rolleddNumber != null) {
            System.out.println("第一个if");
            ChessPiece piece = model.getChessPieceAt(location);
            if (piece.getPlayer() == currentPlayer) {
                System.out.println("2 if");
                if (model.getMoveChessPiece(location, step).getColor() == piece.getPlayer() && model.getMoveChessPiece(location, step).getIndex() == 4) {
                    System.out.println("di yi ge if");
                    ChessBoardLocation afterMove = model.getMoveChessPiece(location, step);
                    int x = afterMove.getColor();
                    int y = afterMove.getIndex() + 3;
                    if (model.getGrid()[x][y].getPiece() != null) {
                        if (model.getGrid()[x][y].getPiece().getPlayer() != currentPlayer) {
                            getHome(model.getGrid()[x][y].getPiece().getPlayer(), model.getGrid()[x][y].getPiece().getScore());
                            model.jump(location, step);
                        } else if (model.getGrid()[x][y].getPiece().getPlayer() == currentPlayer && model.getGrid()[x][y].getPiece().getScore() == 1 && piece.getScore() == 1) {
                            model.moveChessPiece(location, step);
                            model.dieQi(new ChessBoardLocation(x, y), new ChessPiece2(currentPlayer));
                            System.out.println(model.getGrid()[x][y].getPiece());
                            System.out.println("x2");
                        } else if (model.getGrid()[x][y].getPiece().getPlayer() == currentPlayer && ((model.getGrid()[x][y].getPiece().getScore() == 2 && piece.getScore() == 1) || (model.getGrid()[x][y].getPiece().getScore() == 1 && piece.getScore() == 2))) {
                            model.moveChessPiece(location, step);
                            model.dieQi(new ChessBoardLocation(x, y), new ChessPiece3(currentPlayer));
                            System.out.println(model.getGrid()[x][y].getPiece());
                            System.out.println("x3");
                        } else if (model.getGrid()[x][y].getPiece().getPlayer() == currentPlayer && ((model.getGrid()[x][y].getPiece().getScore() == 2 && piece.getScore() == 2) || (model.getGrid()[x][y].getPiece().getScore() == 1 && piece.getScore() == 3) || (model.getGrid()[x][y].getPiece().getScore() == 3 && piece.getScore() == 1))) {
                            model.moveChessPiece(location, step);
                            model.dieQi(new ChessBoardLocation(x, y), new ChessPiece4(currentPlayer));
                            System.out.println(model.getGrid()[x][y].getPiece());
                            System.out.println("x4");
                        }

                    } else model.jump(location, step);


                } else if (piece.getPlayer() == model.getMoveChessPiece(location, step).getColor() && model.getMoveChessPiece(location, step).getIndex() < 12) {
                    System.out.println("di er ge else if");
                    ChessBoardLocation afterMove1 = model.getMoveChessPiece1(location, step);
                    int x = afterMove1.getColor();
                    int y = afterMove1.getIndex();
                    if (model.getGrid()[x][y].getPiece() != null) {
                        if (model.getGrid()[x][y].getPiece().getPlayer() != currentPlayer) {
                            getHome(model.getGrid()[x][y].getPiece().getPlayer(), model.getGrid()[x][y].getPiece().getScore());
                            model.moveChessPiece1(location, step);
                        } else if (model.getGrid()[x][y].getPiece().getPlayer() == currentPlayer && model.getGrid()[x][y].getPiece().getScore() == 1 && piece.getScore() == 1) {
                            model.moveChessPiece(location, step);
                            model.dieQi(new ChessBoardLocation(x, y), new ChessPiece2(currentPlayer));
                            System.out.println(model.getGrid()[x][y].getPiece());
                            System.out.println("x2");
                        } else if (model.getGrid()[x][y].getPiece().getPlayer() == currentPlayer && ((model.getGrid()[x][y].getPiece().getScore() == 2 && piece.getScore() == 1) || (model.getGrid()[x][y].getPiece().getScore() == 1 && piece.getScore() == 2))) {
                            model.moveChessPiece(location, step);
                            model.dieQi(new ChessBoardLocation(x, y), new ChessPiece3(currentPlayer));
                            System.out.println(model.getGrid()[x][y].getPiece());
                            System.out.println("x3");
                        } else if (model.getGrid()[x][y].getPiece().getPlayer() == currentPlayer && ((model.getGrid()[x][y].getPiece().getScore() == 2 && piece.getScore() == 2) || (model.getGrid()[x][y].getPiece().getScore() == 1 && piece.getScore() == 3) || (model.getGrid()[x][y].getPiece().getScore() == 3 && piece.getScore() == 1))) {
                            model.moveChessPiece(location, step);
                            model.dieQi(new ChessBoardLocation(x, y), new ChessPiece4(currentPlayer));
                            System.out.println(model.getGrid()[x][y].getPiece());
                            System.out.println("x4");
                        }

                    } else model.moveChessPiece1(location, step);


                } else {
                    System.out.println("sIPLE ELSE");
                    ChessBoardLocation afterMove = model.getMoveChessPiece(location, step);
                    int x = afterMove.getColor();
                    int y = afterMove.getIndex();
                    if (model.getGrid()[x][y].getPiece() != null) {
                        if (model.getGrid()[x][y].getPiece().getPlayer() != currentPlayer) {
                            getHome(model.getGrid()[x][y].getPiece().getPlayer(), model.getGrid()[x][y].getPiece().getScore());
                            model.moveChessPiece(location, step);
                            System.out.println("move");
                        } else if (model.getGrid()[x][y].getPiece().getPlayer() == currentPlayer && model.getGrid()[x][y].getPiece().getScore() == 1 && piece.getScore() == 1) {
                            model.moveChessPiece(location, step);
                            model.dieQi(new ChessBoardLocation(x, y), new ChessPiece2(currentPlayer));
                            System.out.println(model.getGrid()[x][y].getPiece());
                            System.out.println("x2");
                        } else if (model.getGrid()[x][y].getPiece().getPlayer() == currentPlayer && ((model.getGrid()[x][y].getPiece().getScore() == 2 && piece.getScore() == 1) || (model.getGrid()[x][y].getPiece().getScore() == 1 && piece.getScore() == 2))) {
                            model.moveChessPiece(location, step);
                            model.dieQi(new ChessBoardLocation(x, y), new ChessPiece3(currentPlayer));
                            System.out.println(model.getGrid()[x][y].getPiece());
                            System.out.println("x3");
                        } else if (model.getGrid()[x][y].getPiece().getPlayer() == currentPlayer && ((model.getGrid()[x][y].getPiece().getScore() == 2 && piece.getScore() == 2) || (model.getGrid()[x][y].getPiece().getScore() == 1 && piece.getScore() == 3) || (model.getGrid()[x][y].getPiece().getScore() == 3 && piece.getScore() == 1))) {
                            model.moveChessPiece(location, step);
                            model.dieQi(new ChessBoardLocation(x, y), new ChessPiece4(currentPlayer));
                            System.out.println(model.getGrid()[x][y].getPiece());
                            System.out.println("x4");
                        }

                    } else {
                        model.moveChessPiece(location, step);
                        System.out.println("simple Move");
                    }

                }
                if (model.getMoveChessPiece(location, step).getIndex() == 18) {
                    grade[currentPlayer] = grade[currentPlayer] + piece.getScore();
                    if (grade[currentPlayer] == 4) {
                        GameFrame.gameOver();
                    }
                    model.removeChessPieceAt(model.getMoveChessPiece(location, step));
                    model.judge(currentPlayer);
                    System.out.println(grade[currentPlayer]);
                }
                listenerList.forEach(listener -> listener.onPlayerEndRound(currentPlayer));
                nextPlayer();
                listenerList.forEach(listener -> listener.onPlayerStartRound(currentPlayer));
            }
        }
    }


    public void takeOff() {
        if (getRolledNumber() == 6 || getRolleddNumber() == 6) {
            if (model.getGrid()[currentPlayer][19].getPiece() != null) {
                model.removeChessPieceAt(new ChessBoardLocation(currentPlayer, 19));
                if(model.getGrid()[currentPlayer][23].getPiece()!=null){
                    if(model.getGrid()[currentPlayer][23].getPiece().getScore()==1){
                        model.dieQi(new ChessBoardLocation(currentPlayer, 23), new ChessPiece2(currentPlayer));
                    }
                    else if(model.getGrid()[currentPlayer][23].getPiece().getScore()==2){
                        model.dieQi(new ChessBoardLocation(currentPlayer, 23), new ChessPiece3(currentPlayer));
                    }
                    else if(model.getGrid()[currentPlayer][23].getPiece().getScore()==3){
                        model.dieQi(new ChessBoardLocation(currentPlayer, 23), new ChessPiece4(currentPlayer));
                    }

                }
                else {model.setChessPieceAt(new ChessBoardLocation(currentPlayer, 23), new ChessPiece(currentPlayer));}
                state[currentPlayer] = true;
                listenerList.forEach(listener -> listener.onPlayerEndRound(currentPlayer));
                nextPlayer();
                listenerList.forEach(listener -> listener.onPlayerStartRound(currentPlayer));
                System.out.println("1");
            } else if (model.getGrid()[currentPlayer][20].getPiece() != null) {
                model.removeChessPieceAt(new ChessBoardLocation(currentPlayer, 20));
                if(model.getGrid()[currentPlayer][23].getPiece()!=null){
                    if(model.getGrid()[currentPlayer][23].getPiece().getScore()==1){
                        model.dieQi(new ChessBoardLocation(currentPlayer, 23), new ChessPiece2(currentPlayer));
                    }
                    else if(model.getGrid()[currentPlayer][23].getPiece().getScore()==2){
                        model.dieQi(new ChessBoardLocation(currentPlayer, 23), new ChessPiece3(currentPlayer));
                    }
                    else if(model.getGrid()[currentPlayer][23].getPiece().getScore()==3){
                        model.dieQi(new ChessBoardLocation(currentPlayer, 23), new ChessPiece4(currentPlayer));
                    }

                }
                else {model.setChessPieceAt(new ChessBoardLocation(currentPlayer, 23), new ChessPiece(currentPlayer));}
                state[currentPlayer] = true;
                listenerList.forEach(listener -> listener.onPlayerEndRound(currentPlayer));
                nextPlayer();
                listenerList.forEach(listener -> listener.onPlayerStartRound(currentPlayer));
                System.out.println("2");
            } else if (model.getGrid()[currentPlayer][21].getPiece() != null) {
                model.removeChessPieceAt(new ChessBoardLocation(currentPlayer, 21));
                if(model.getGrid()[currentPlayer][23].getPiece()!=null){
                    if(model.getGrid()[currentPlayer][23].getPiece().getScore()==1){
                        model.dieQi(new ChessBoardLocation(currentPlayer, 23), new ChessPiece2(currentPlayer));
                    }
                    else if(model.getGrid()[currentPlayer][23].getPiece().getScore()==2){
                        model.dieQi(new ChessBoardLocation(currentPlayer, 23), new ChessPiece3(currentPlayer));
                    }
                    else if(model.getGrid()[currentPlayer][23].getPiece().getScore()==3){
                        model.dieQi(new ChessBoardLocation(currentPlayer, 23), new ChessPiece4(currentPlayer));
                    }

                }
                else {model.setChessPieceAt(new ChessBoardLocation(currentPlayer, 23), new ChessPiece(currentPlayer));}
                state[currentPlayer] = true;
                listenerList.forEach(listener -> listener.onPlayerEndRound(currentPlayer));
                nextPlayer();
                listenerList.forEach(listener -> listener.onPlayerStartRound(currentPlayer));
            } else if (model.getGrid()[currentPlayer][22].getPiece() != null) {
                model.removeChessPieceAt(new ChessBoardLocation(currentPlayer, 22));
                if(model.getGrid()[currentPlayer][23].getPiece()!=null){
                    if(model.getGrid()[currentPlayer][23].getPiece().getScore()==1){
                        model.dieQi(new ChessBoardLocation(currentPlayer, 23), new ChessPiece2(currentPlayer));
                    }
                    else if(model.getGrid()[currentPlayer][23].getPiece().getScore()==2){
                        model.dieQi(new ChessBoardLocation(currentPlayer, 23), new ChessPiece3(currentPlayer));
                    }
                    else if(model.getGrid()[currentPlayer][23].getPiece().getScore()==3){
                        model.dieQi(new ChessBoardLocation(currentPlayer, 23), new ChessPiece4(currentPlayer));
                    }

                }
                else {model.setChessPieceAt(new ChessBoardLocation(currentPlayer, 23), new ChessPiece(currentPlayer));}
                state[currentPlayer] = true;
                setAllTakeOff(currentPlayer, true);
                listenerList.forEach(listener -> listener.onPlayerEndRound(currentPlayer));
                nextPlayer();
                listenerList.forEach(listener -> listener.onPlayerStartRound(currentPlayer));
            }
        }

    }

    public void setStep(int step) {
        this.step = step;
    }

    public static int getRolledNumber() {
        return rolledNumber;
    }

    public static int getRolleddNumber() {
        return rolleddNumber;
    }

    public static ChessBoard getChessBoard() {
        return model;
    }

    public static boolean getState(int currentPlayer) {
        return state[currentPlayer];
    }

    public static void setState(int currentPlayer, boolean x) {
        state[currentPlayer] = x;
    }

    public static boolean getAllTakeOff(int currentPlayer) {
        return allTakeOff[currentPlayer];
    }

    public static void setAllTakeOff(int currentPlayer, boolean x) {
        allTakeOff[currentPlayer] = x;
    }

    public static void getHome(int homePlayer,int score) {
        System.out.println(homePlayer);
        System.out.printf("sore: %d ",score);
        if(score==1) {
            System.out.println("jinqu");
            for (int i = 19; i < 23; i++) {
                if (model.getGrid()[homePlayer][i].getPiece() == null) {
                    model.setChessPieceAt(new ChessBoardLocation(homePlayer, i), new ChessPiece(homePlayer));
                    break;
                }
            }
        }
        else if(score == 2) {
            int x =0;
            for (int i = 19; i < 23; i++) {
                if (model.getGrid()[homePlayer][i].getPiece() == null) {
                    model.setChessPieceAt(new ChessBoardLocation(homePlayer, i), new ChessPiece(homePlayer));
                    x+=1;
                }
                if(x==2) break;
            }
        }
        else if(score == 3) {
            int x =0;
            for (int i = 19; i < 23; i++) {
                if (model.getGrid()[homePlayer][i].getPiece() == null) {
                    model.setChessPieceAt(new ChessBoardLocation(homePlayer, i), new ChessPiece(homePlayer));
                    x+=1;
                }
                if(x==3) break;
            }
        }
        else {
            for (int i = 19; i < 23; i++) {
                if (model.getGrid()[homePlayer][i].getPiece() == null) {
                    model.setChessPieceAt(new ChessBoardLocation(homePlayer, i), new ChessPiece(homePlayer));
                }
            }
        }
        int count = 0;
        for (int i = 19; i < 23; i++) {
            if (model.getGrid()[homePlayer][i].getPiece() != null) {
                count++;
            }
        }
        if(count>0){
            setAllTakeOff(homePlayer,false);
        }
        if (count == 4) {
            setState(homePlayer, false);
        }
    }

    public static void setRolledNumber(int number) {
        rolledNumber = number;
    }

    public static void setRolleddNumber(int number) {
        rolleddNumber = number;
    }

    public static int getGrade(int currentPlayer){
        return grade[currentPlayer];
    }

    public static String getColor(int currentPlayer){
        String color ="";
        switch (currentPlayer){
            case 0:color ="Yellow";
            case 1:color= "Blue";
            case 2:color= "Green";
            case 3:color= "Red";
        }
        System.out.println(currentPlayer);
        return color;
    }

    @Override
    public void registerListener(GameStateListener listener) {
        listenerList.add(listener);
    }

    @Override
    public void unregisterListener(GameStateListener listener) {
        listenerList.remove(listener);
    }
}
