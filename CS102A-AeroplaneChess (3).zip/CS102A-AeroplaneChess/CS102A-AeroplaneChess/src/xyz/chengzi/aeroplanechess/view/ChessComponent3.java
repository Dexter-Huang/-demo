package xyz.chengzi.aeroplanechess.view;

import java.awt.*;

public class ChessComponent3 extends ChessComponent{
    private Color color;
    private String[] filename ={"CS102A-AeroplaneChess/src/xyz/chengzi/aeroplanechess/view/yellowpiecex3.png",
            "CS102A-AeroplaneChess/src/xyz/chengzi/aeroplanechess/view/bluepiecex3.png",
            "CS102A-AeroplaneChess/src/xyz/chengzi/aeroplanechess/view/redpiecex3.png",
            "CS102A-AeroplaneChess/src/xyz/chengzi/aeroplanechess/view/greenpiecex3.png"};
    public ChessComponent3(Color color){
        super(color);
        this.color=color;
    }
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        paintChess(g);
    }
    private void paintChess(Graphics g) {
        //((Graphics2D) g).setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        g.setColor(color);
        int aa=0;
        if(color .equals( Color.YELLOW.darker())){
            Image i=Toolkit.getDefaultToolkit().getImage(filename[aa]);
            g.drawImage(i,2,2,50,50,this);

        }else if(color.equals(Color.BLUE.darker())){
            Image i=Toolkit.getDefaultToolkit().getImage(filename[aa+1]);
            g.drawImage(i,2,2,50,50,this);

        }else if(color.equals(Color.RED.darker())){
            Image i=Toolkit.getDefaultToolkit().getImage(filename[aa+2]);
            g.drawImage(i,2,2,50,50,this);

        }else if(color.equals(Color.GREEN.darker())){
            Image i=Toolkit.getDefaultToolkit().getImage(filename[aa+3]);
            g.drawImage(i,2,2,50,50,this);
        }

    }
}