package xyz.chengzi.aeroplanechess.model;

public class ChessPiece3 extends ChessPiece {
    private final int player;
    private final int score = 3;

    public ChessPiece3(int player) {
        super(player);
        this.player = player;
    }
    public int getPlayer() {
        return player;
    }
    public int getScore(){ return score;}
}

