package xyz.chengzi.aeroplanechess.model;

public class ChessPiece2 extends ChessPiece {
    private final int player;
    private final int score =2;
    public ChessPiece2(int player){
        super(player);
        this.player=player;
    }
    public int getPlayer() {
        return player;
    }
    public int getScore(){ return score;}
}

