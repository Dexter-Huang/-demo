package xyz.chengzi.aeroplanechess.model;

import xyz.chengzi.aeroplanechess.listener.ChessBoardListener;
import xyz.chengzi.aeroplanechess.listener.Listenable;
import xyz.chengzi.aeroplanechess.controller.GameController;

import java.util.ArrayList;
import java.util.List;


public class ChessBoard implements Listenable<ChessBoardListener> {
    private final List<ChessBoardListener> listenerList = new ArrayList<>();
    private final Square[][] grid;
    private final int dimension, endDimension;
    private boolean exc = false;

    public ChessBoard(int dimension, int endDimension) {
        this.grid = new Square[4][dimension + endDimension+5];
        this.dimension = dimension;
        this.endDimension = endDimension;

        initGrid();
    }
    public Square[][] getGrid(){
        return grid;
    }
    public List<ChessBoardListener> getListenerList(){
        return listenerList;
    }
    private void initGrid() {
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < dimension + endDimension+5; j++) {
                grid[i][j] = new Square(new ChessBoardLocation(i, j)); //初始化，用一个二维数组来表示飞机跑道
            }
        }

    }

    public void placeInitialPieces() {
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < dimension + endDimension+5; j++) {
                grid[i][j].setPiece( null); //把每一个格子里的旗子设为空。
            }
        }
        // FIXME: Demo implementation
       for(int player = 0 ;player<4;player++){
           for(int index =19;index<23;index++){
               grid[player][index].setPiece(new ChessPiece(player));
           }
       }
        listenerList.forEach(listener -> listener.onChessBoardReload(this));

    }

    public Square getGridAt(ChessBoardLocation location) {
        return grid[location.getColor()][location.getIndex()];
    }

    public int getDimension() {
        return dimension;
    }

    public int getEndDimension() {
        return endDimension;
    }

    public ChessPiece getChessPieceAt(ChessBoardLocation location) {
        return getGridAt(location).getPiece();
    }

    public void setChessPieceAt(ChessBoardLocation location, ChessPiece piece) {
        getGridAt(location).setPiece(piece);
        listenerList.forEach(listener -> listener.onChessPiecePlace(location, piece));
    }
public  void dieQi(ChessBoardLocation location,ChessPiece piece){
    setChessPieceAt(location,piece);
    listenerList.forEach(listener -> listener.onChessBoardReload(this));
}

    public ChessPiece removeChessPieceAt(ChessBoardLocation location) {
        ChessPiece piece = getGridAt(location).getPiece();
        getGridAt(location).setPiece(null);
        listenerList.forEach(listener -> listener.onChessPieceRemove(location));
        return piece;
    }

    public void  moveChessPiece(ChessBoardLocation src, int steps) {
        ChessBoardLocation temp = src;
        if(src.getIndex()==23){
            src =new ChessBoardLocation(src.getColor(), 0);
            steps-=1;
        }
        ChessBoardLocation dest = src;
        // FIXME: This just naively move the chess forward without checking anything

            for (int i = 0; i < steps; i++) {
                dest = nextLocation(dest);
            }
        exc= false;
        setChessPieceAt(dest, removeChessPieceAt(temp));
        listenerList.forEach(listener -> listener.onChessBoardReload(this));

    }
    public ChessBoardLocation getMoveChessPiece(ChessBoardLocation src, int steps) {
        if(src.getIndex()==23){
            src =new ChessBoardLocation(src.getColor(), 0);
            steps-=1;
        }
        ChessBoardLocation dest = src;
        // FIXME: This just naively move the chess forward without checking anything

        for (int i = 0; i < steps; i++) {
            dest = nextLocation(dest);
        }
        exc= false;
        return dest;
    }
    public void moveChessPiece1(ChessBoardLocation src, int steps) {
        ChessBoardLocation temp = src;
        if(src.getIndex()==23){
            src =new ChessBoardLocation(src.getColor(), 0);
            steps-=1;
        }
        ChessBoardLocation dest = src;
        // FIXME: This just naively move the chess forward without checking anything
        for (int i = 0; i < steps+4; i++) {
            dest = nextLocation(dest);
        }
        exc= false;
        setChessPieceAt(dest, removeChessPieceAt(temp));
        listenerList.forEach(listener -> listener.onChessBoardReload(this));
    }
    public ChessBoardLocation getMoveChessPiece1(ChessBoardLocation src, int steps) {
        if(src.getIndex()==23){
            src =new ChessBoardLocation(src.getColor(), 0);
            steps-=1;
        }
        ChessBoardLocation dest = src;
        // FIXME: This just naively move the chess forward without checking anything
        for (int i = 0; i < steps+4; i++) {
            dest = nextLocation(dest);
        }
        exc= false;
        return dest;
    }
    public void jump(ChessBoardLocation src, int steps){
        knockOff(src);
        moveChessPiece(src,steps);
        setChessPieceAt(new ChessBoardLocation(GameController.getCurrentPlayer(), 7), removeChessPieceAt(new ChessBoardLocation(GameController.getCurrentPlayer(),4)));
        listenerList.forEach(listener -> listener.onChessBoardReload(this));
    }

    //撞飞
    public void knockOff(ChessBoardLocation src){
        if(grid[src.getColor()][src.getIndex()].getPiece().getPlayer()>=2&&grid[grid[src.getColor()][src.getIndex()].getPiece().getPlayer()-2][15].getPiece()!=null){
       removeChessPieceAt(new ChessBoardLocation(grid[src.getColor()][src.getIndex()].getPiece().getPlayer()-2,15 ));
        GameController.getHome(grid[src.getColor()][src.getIndex()].getPiece().getPlayer()-2,grid[grid[src.getColor()][src.getIndex()].getPiece().getPlayer()-2][15].getPiece().getScore());
        }
        else if(grid[src.getColor()][src.getIndex()].getPiece().getPlayer()<2&&grid[grid[src.getColor()][src.getIndex()].getPiece().getPlayer()+2][15].getPiece()!=null) {

            GameController.getHome(grid[src.getColor()][src.getIndex()].getPiece().getPlayer()+2,grid[grid[src.getColor()][src.getIndex()].getPiece().getPlayer()+2][15].getPiece().getScore());
            removeChessPieceAt(new ChessBoardLocation(grid[src.getColor()][src.getIndex()].getPiece().getPlayer()+2,15 ));
        }
    }

    public ChessBoardLocation nextLocation(ChessBoardLocation location) {
        // FIXME :This move the chess to next jump location instead of nearby next location
        int x = 0;
        int y = 0;

        if (location.getIndex() == 18) {
            this.exc = true;
        }
        if (!exc) {
            if (location.getColor() < 3) {
                if (location.getIndex() >= 0 && location.getIndex() < 3) {
                    x = location.getColor() + 1;
                    y = location.getIndex() + 10;
                }
                if (location.getIndex() >= 3 && location.getIndex() < 12) {
                    x = location.getColor() + 1;
                    y = location.getIndex() - 3;
                }
                if (location.getIndex() >= 12 && location.getColor() != GameController.getCurrentPlayer()) {
                    x = location.getColor() + 1;
                    y = location.getIndex() - 3;
                }

            } else {
                if (location.getIndex() >= 0 && location.getIndex() <= 2) {
                    x = 0;
                    y = location.getIndex() + 10;
                }
                if (location.getIndex() > 2 && location.getIndex() < 12) {
                    x = 0;
                    y = location.getIndex() - 3;
                }
                if (location.getIndex() >= 12 && location.getColor() != GameController.getCurrentPlayer()) {
                    x = 0;
                    y = location.getIndex() - 3;
                }

            }
            if (location.getIndex() >= 12 && location.getColor() == GameController.getCurrentPlayer()) {
                x = location.getColor();
                y = location.getIndex() + 1;
            }
        }
        else {
            if (location.getIndex() > 12) {
                x = location.getColor();
                y = location.getIndex() - 1;
            } else {
                if (location.getColor() != 0) {
                    if (location.getIndex() >= 10 && location.getIndex() <= 12) {
                        x = location.getColor() - 1;
                        y = location.getIndex() - 10;
                    }
                    if (location.getIndex() >= 0 && location.getIndex() < 10) {
                        x = location.getColor() - 1;
                        y = location.getIndex() + 3;
                    }
                } else {
                    if (location.getIndex() >= 10 && location.getIndex() <= 12) {
                        x = 3;
                        y = location.getIndex() - 10;
                    }
                    if (location.getIndex() >= 0 && location.getIndex() < 10) {
                        x = 3;
                        y = location.getIndex() + 3;
                    }
                }
            }

        }

        return new ChessBoardLocation(x, y);

    }

    public void judge(int currentPlayer){
        int count =0;
            for(int i =19;i<=22;i++) {
                if (grid[currentPlayer][i].getPiece() != null) {
                    if (grid[currentPlayer][i].getPiece().getPlayer() == GameController.getCurrentPlayer()) {
                        count++;
                    }
                }
            }
            if(count==4) GameController.setState(GameController.getCurrentPlayer(),false);

    }


    @Override
    public void registerListener(ChessBoardListener listener) {
        listenerList.add(listener);
    }

    @Override
    public void unregisterListener(ChessBoardListener listener) {
        listenerList.remove(listener);
    }
}
