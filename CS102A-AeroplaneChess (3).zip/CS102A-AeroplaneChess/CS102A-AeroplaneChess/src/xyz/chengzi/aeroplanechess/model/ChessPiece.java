package xyz.chengzi.aeroplanechess.model;

public class ChessPiece {
    private final int player;
    private final int score =1;

    public ChessPiece(int player) {
        this.player = player;
    }

    public int getPlayer() {
        return player;
    }
    public int getScore(){ return score;}
}
