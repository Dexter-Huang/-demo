package xyz.chengzi.aeroplanechess.view;

import javax.swing.*;
import java.awt.*;

public class ChessComponent extends JComponent {
    private Color color;

    private String[] filename={"CS102A-AeroplaneChess/src/Imange/yellowpiece.png",
            "CS102A-AeroplaneChess/src/Imange/bluepiece.png",
            "CS102A-AeroplaneChess/src/Imange/redpiece.png",
            "CS102A-AeroplaneChess/src/Imange/greenpiece.png"};

    public ChessComponent(Color color) {
        this.color = color;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        paintChess(g);
    }

    private void paintChess(Graphics g) {
        //((Graphics2D) g).setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        g.setColor(color);
        int aa=0;
        if(color .equals( Color.YELLOW.darker())){
            Image i=Toolkit.getDefaultToolkit().getImage(filename[aa]);
            g.drawImage(i,2,2,50,50,this);

        }else if(color.equals(Color.BLUE.darker())){
            Image i=Toolkit.getDefaultToolkit().getImage(filename[aa+1]);
            g.drawImage(i,2,2,50,50,this);

        }else if(color.equals(Color.RED.darker())){
            Image i=Toolkit.getDefaultToolkit().getImage(filename[aa+2]);
            g.drawImage(i,2,2,50,50,this);

        }else if(color.equals(Color.GREEN.darker())){
            Image i=Toolkit.getDefaultToolkit().getImage(filename[aa+3]);
            g.drawImage(i,2,2,50,50,this);
        }
//        ((Graphics2D) g).setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
//
//        int spacing = (int) (getWidth() * 0.25);
//        g.setColor(color);
//        g.fillOval(spacing, spacing, getWidth() - 2 * spacing, getHeight() - 2 * spacing);
    }
}
