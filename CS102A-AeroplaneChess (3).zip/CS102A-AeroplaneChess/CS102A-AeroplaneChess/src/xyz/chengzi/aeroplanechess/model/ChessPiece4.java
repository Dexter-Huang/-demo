package xyz.chengzi.aeroplanechess.model;

public class ChessPiece4 extends ChessPiece {
    private final int player;
    private final int score =4;
    public ChessPiece4(int player){
        super(player);
        this.player=player;
    }
    public int getPlayer() {
        return player;
    }
    public int getScore(){ return score;}
}