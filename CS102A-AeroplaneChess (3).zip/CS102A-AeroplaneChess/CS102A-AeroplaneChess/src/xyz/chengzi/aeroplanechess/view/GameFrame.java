package xyz.chengzi.aeroplanechess.view;


import xyz.chengzi.aeroplanechess.controller.GameController;
import xyz.chengzi.aeroplanechess.listener.GameStateListener;
import javax.swing.*;
import java.awt.*;

public class GameFrame extends JFrame implements GameStateListener {
    private static final String[] PLAYER_NAMES = {"Yellow", "Blue", "Green", "Red"};

    private final JLabel statusLabel = new JLabel();

    private static JLabel ter = new JLabel("Game Over!\n CurrentPlay is Winner!!!");

    private final JDialog SelectStep = new JDialog(this,"选择步数",true);
    private final JDialog show = new JDialog(this,"太可惜了",true);
    private final JDialog ch = new JDialog(this,"Congratulation!",true);
    private static final JFrame terminate = new JFrame();
    private JPanel jp =new JPanel();
    private JPanel jp1 =new JPanel();
    private GameController controller;
    int dice,ddice;


    public static boolean YState = false;


    public GameFrame(GameController controller) {
        terminate.setLocationRelativeTo(null);
        terminate.setSize(300,130);
        terminate.add(ter);
        SelectStep.setLocationRelativeTo(null);
        SelectStep.setSize(200,130);
        SelectStep.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        show.setLocationRelativeTo(null);
        show.setSize(200,130);
        show.add(new JLabel("              你没有掷到六"));

        ch.setSize(200,130);
        ch.setLocationRelativeTo(null);

        this.controller =controller;

        setTitle("2020 CS102A Project Demo");
        setSize(772, 825);
        setLocationRelativeTo(null); // Center the window
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setLayout(null);

        statusLabel.setLocation(0, 758);
        statusLabel.setFont(statusLabel.getFont().deriveFont(18.0f));
        statusLabel.setSize(400, 20);
        add(statusLabel);



        DiceSelectorComponent diceSelectorComponent = new DiceSelectorComponent();
        diceSelectorComponent.setLocation(396, 758);
        add(diceSelectorComponent);

        JButton button = new JButton("roll");

        button.addActionListener((e) -> {
            if (diceSelectorComponent.isRandomDice()) {
                 dice = controller.rollDice();
                 ddice = controller.rollDdice();
                if (dice != -1&&ddice != -1) {
                    if(!GameController.getState(GameController.getCurrentPlayer())&&dice!=6&&ddice!=6){
                        show.setVisible(true);
                        GameController.nextPlayer();
                        this.onPlayerStartRound(GameController.getCurrentPlayer());
                    }
                    else if(dice==6||ddice==6){
                        choose();
                        this.onPlayerStartRound(GameController.getCurrentPlayer());
                    }
                     else{
                        statusLabel.setText(String.format("[%s] Rolled a %c (%d) and a %c (%d)",
                                PLAYER_NAMES[controller.getCurrentPlayer()], '\u267F' + dice, dice, '\u267F' + ddice, ddice));
                        if(dice+ddice<=12){
                        makeButton(String.format("%d + %d = %d", dice, ddice, dice + ddice));}
                        if (dice >= ddice&&dice-ddice<=12) {
                            makeButton(String.format("%d - %d = %d", dice, ddice, dice - ddice));
                        }
                        if (dice < ddice&&ddice-dice<=12) {
                            makeButton(String.format("%d - %d = %d", ddice, dice, ddice - dice));
                        }
                        if(dice*ddice<=12){
                        makeButton(String.format("%d * %d = %d", dice, ddice, dice * ddice));}
                        if (dice % ddice == 0) {
                            makeButton(String.format("%d / %d = %d", dice, ddice, dice / ddice));
                        }
                        if (dice != ddice && ddice % dice == 0) {
                            makeButton(String.format("%d / %d = %d", ddice, dice, ddice / dice));
                        }
                        SelectStep.add(jp, BorderLayout.CENTER);
                        SelectStep.setVisible(true);
                    }
                } else {
                    JOptionPane.showMessageDialog(this, "You have already rolled the dice,\n or the last player don't take off!");
                }
            } else {
                    System.out.println("manual");
                dice = GameController.getRolledNumber();
                ddice = GameController.getRolleddNumber();
                if (dice != -1&&ddice != -1) {
                    if(!GameController.getState(GameController.getCurrentPlayer())&&dice!=6&&ddice!=6){
                        show.setVisible(true);
                        GameController.nextPlayer();
                        this.onPlayerStartRound(GameController.getCurrentPlayer());
                    }
                    else if((dice==6||ddice==6)) {
                        choose();
                        this.onPlayerStartRound(GameController.getCurrentPlayer());
                    }
                    else{
                        statusLabel.setText(String.format("[%s] Rolled a %c (%d) and a %c (%d)",
                                PLAYER_NAMES[controller.getCurrentPlayer()], '\u267F' + dice, dice, '\u267F' + ddice, ddice));
                        if(dice+ddice<=12){
                            makeButton(String.format("%d + %d = %d", dice, ddice, dice + ddice));}
                        if (dice >= ddice&&dice-ddice<=12) {
                            makeButton(String.format("%d - %d = %d", dice, ddice, dice - ddice));
                        }
                        if (dice < ddice&&ddice-dice<=12) {
                            makeButton(String.format("%d - %d = %d", ddice, dice, ddice - dice));
                        }
                        if(dice*ddice<=12){
                            makeButton(String.format("%d * %d = %d", dice, ddice, dice * ddice));}
                        if (dice % ddice == 0) {
                            makeButton(String.format("%d / %d = %d", dice, ddice, dice / ddice));
                        }
                        if (dice != ddice && ddice % dice == 0) {
                            makeButton(String.format("%d / %d = %d", ddice, dice, ddice / dice));
                        }
                        SelectStep.add(jp, BorderLayout.CENTER);
                        SelectStep.setVisible(true);
                    }
                }
            }
        });
        button.setLocation(668, 756);
        button.setFont(button.getFont().deriveFont(18.0f));
        button.setSize(90, 30);
        add(button);
    }



    @Override
    public void onPlayerStartRound(int player) {
        statusLabel.setText(String.format("[%s] Please roll the dice", PLAYER_NAMES[player]));
    }

    @Override
    public void onPlayerEndRound(int player) {

    }
    public void makeButton(String x) {
        String[] str =x.split(" ");
        int a = Integer.parseInt(str[0]);
        int b = Integer.parseInt(str[2]);
        JButton but = new JButton(x);
        jp.add(but);
                but.addActionListener(event ->
                {
                    if(str[1].equals("+")){
                    controller.setStep(a+b);
                }
                    if(str[1].equals("-")){
                        controller.setStep(Math.max(a,b)-Math.min(a,b));
                    }
                    if(str[1].equals("*")){
                        controller.setStep(a*b);
                    }
                    if(str[1].equals("/")){
                        controller.setStep(Math.max(a,b)/Math.min(a,b));
                    }
                    SelectStep.dispose();
                    jp.removeAll();
                }
       );
    }
    public void choose(){
        if(GameController.getState(GameController.getCurrentPlayer())){
            System.out.println("choose");
            statusLabel.setText(String.format("[%s] Rolled a %c (%d) and a %c (%d)",
                    PLAYER_NAMES[controller.getCurrentPlayer()], '\u267F' + dice, dice, '\u267F' + ddice, ddice));
        JButton jb1 = new JButton("move");
            jp1.add(jb1);
            jb1.addActionListener(e->{
                ch.dispose();
                jp1.removeAll();
                statusLabel.setText(String.format("[%s] Rolled a %c (%d) and a %c (%d)",
                        PLAYER_NAMES[controller.getCurrentPlayer()], '\u267F' + dice, dice, '\u267F' + ddice, ddice));
                if(dice+ddice<=12){
                    makeButton(String.format("%d + %d = %d", dice, ddice, dice + ddice));}
                if (dice >= ddice&&dice-ddice<=12) {
                    makeButton(String.format("%d - %d = %d", dice, ddice, dice - ddice));
                }
                if (dice < ddice&&ddice-dice<=12) {
                    makeButton(String.format("%d - %d = %d", ddice, dice, ddice - dice));
                }
                if(dice*ddice<=12){
                    makeButton(String.format("%d * %d = %d", dice, ddice, dice * ddice));}
                if (dice % ddice == 0) {
                    makeButton(String.format("%d / %d = %d", dice, ddice, dice / ddice));
                }
                if (dice != ddice && ddice % dice == 0) {
                    makeButton(String.format("%d / %d = %d", ddice, dice, ddice / dice));
                }
                SelectStep.add(jp, BorderLayout.CENTER);
                SelectStep.setVisible(true);
            });
        }
        if(!GameController.getAllTakeOff(GameController.getCurrentPlayer())){
            JButton jb = new JButton("take off");
            jp1.add(jb);
            jb.addActionListener(e->{
                controller.takeOff();
                ch.dispose();
                jp1.removeAll();
            });
        }

        ch.add(jp1);
        ch.setSize(300,100);
        jp1.setVisible(true);
        ch.setVisible(true);
    }

    public static void gameOver(){
        terminate.setVisible(true);
    }
}





